import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moments',
  templateUrl: './moments.page.html',
  styleUrls: ['./moments.page.scss'],
})
export class MomentsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
