import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.page.html',
  styleUrls: ['./directives.page.scss'],
})
export class DirectivesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
